package wedesoft.mobinav;

import javax.microedition.lcdui.*;

class CacheEntry {

    int x;
    int y;
    int zoom;

    Image image;

    public CacheEntry( int _x, int _y, int _zoom, Image _image ) {
        x = _x;
        y = _y;
        zoom = _zoom;
        image = _image;
    }
    
    public Image getImage() { return image; }

    boolean match( int _x, int _y, int _zoom ) {
        return
            x == _x &&
            y == _y &&
            zoom == _zoom;
    }
}
