package wedesoft.mobinav;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;

public class MobiNav extends MIDlet {

    private MapCanvas canvas;

    public MobiNav() {
        canvas = new MapCanvas( this );
    }

    public void startApp()  { 
        Display.getDisplay( this ).setCurrent( canvas );
    } 
   
    public void pauseApp () {} 

    public void destroyApp(boolean unconditional) {}
}
