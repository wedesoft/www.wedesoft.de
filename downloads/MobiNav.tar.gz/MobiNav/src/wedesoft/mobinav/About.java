package wedesoft.mobinav;

import javax.microedition.lcdui.*;

public class About {

    private static String copyright =
        "MobiNav software, © 2006 Jan Wedekind\n" +
        "MobiNav is free software; you can redistribute it and/or modify it " +
        "under the terms of the GNU GENERAL PUBLIC LICENSE as published by " +
        "the Free Software Foundation; either version 2 of the License, or " +
        "(at your option) any later version.\n" +
        "MobiNav is distributed in the hope that it will be useful, but " +
        "WITHOUT ANY WARRANTY; without even the implied warranty of " +
        "MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU " +
        "General Public License for more details.\n" +
        "You should have received a copy of the GNU General Public License " +
        "along with MobiNav; if not, contact one of the authors of this " +
        "software.\n" +
        "The map-data was taken from http://wiki.openstreetmap.org/ under the terms and conditions of the Creative Commons Attribution-ShareAlike 2.0 license.\n";

    private Displayable previous;

    private About() {};

    public static void showAbout( Display display ) {

        Alert alert = new Alert("About MoviNav");
        alert.setTimeout(Alert.FOREVER);

        if ( display.isColor() ) {
            try {
                Image image =
                    Image.createImage( "/wedesoft/mobinav/Mercator_World_Map.jpg" );
                alert.setImage(image);
            } catch (java.io.IOException x) {
                // just don't append the image.
            }
        }
        // Add the copyright
        alert.setString(copyright );

        display.setCurrent(alert);
    }

}
