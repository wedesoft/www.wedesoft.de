package wedesoft.mobinav;

import java.io.IOException;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import javax.microedition.midlet.MIDlet;

class MapCanvas extends Canvas implements CommandListener {
   
    MIDlet midlet;
    private Display dpy;

    Command cmdExit;
    Command cmdBack;
    Command cmdZoomIn;
    Command cmdZoomOut;
    Command cmdSetMarker;
    Command cmdOk;
    Command cmdCancel;
    Command cmdReset;
    Command cmdAbout;

    Image mapVendorImage;

    int zoom;
    int posx;
    int posy;
    int maxtiles;

    boolean markerMode;
    boolean hasMarker;
    int markX;
    int markY;
    int oldPosX;
    int oldPosY;

    CacheEntry cache[];

    final static int tilesize = 128;
    final static int markerSize = 15;

    public MapCanvas( MIDlet midlet_ ) {
        midlet = midlet_;
        dpy = Display.getDisplay( midlet );

        cache = new CacheEntry[0];

        markerMode = false;

        cmdExit = new Command( "Exit", Command.EXIT, 1 );
        cmdCancel = new Command( "Cancel", Command.BACK, 1 );
        cmdOk = new Command( "Ok", Command.SCREEN, 2 );
        cmdZoomIn = new Command( "Zoom In", Command.SCREEN, 3 );
        cmdZoomOut = new Command( "Zoom Out", Command.SCREEN, 4 );
        cmdSetMarker = new Command( "Set Marker", Command.SCREEN, 5 );
        cmdReset = new Command( "Reset", Command.SCREEN, 10 );
        cmdAbout = new Command( "About", Command.HELP, 30 );

        loadOptions();

        try {
            mapVendorImage = Image.createImage
                ( "/wedesoft/mobinav/mapvendor.png" );
        } catch (IOException e ) {
            reset();
        }

        setMarkerMode( false );

        setCommandListener( this );
    }

    protected void updateEnabled() {
        if ( maxtiles >= 10 )
            addCommand( cmdZoomOut );
        else
            removeCommand( cmdZoomOut );
        if ( zoom > 1 )
            addCommand( cmdZoomIn );
        else
            removeCommand( cmdZoomIn );
    }

    protected void reset() {
        zoom = 1;
        maxtiles = 10;
        while ( loadTile( 0, 0 ) != null ) {
            maxtiles *= 10;
        };
        maxtiles /= 10;

        posx = getWidth() / 2;
        posy = getHeight() / 2;

        hasMarker = false;
        markX = getWidth() / 2;
        markY = getHeight() / 2;

        updateEnabled();
    }

    public void showNotify() {
    }
    
    public void hideNotify() {
    }

    public void paint(Graphics g) {
        if ( mapVendorImage != null ) {
            int
                w = getWidth(),
                h = getHeight(),
                x0 = posx / zoom - w / 2,
                y0 = posy / zoom - h / 2,
                x1 = x0 + w - 1,
                y1 = y0 + h - 1,
                tx0 = sample( x0, tilesize ),
                ty0 = sample( y0, tilesize ),
                tx1 = sample( x1, tilesize ),
                ty1 = sample( y1, tilesize ),
                cacheIndex = 0;
            CacheEntry newcache[] = new CacheEntry[ ( tx1 + 1 - tx0 ) *
                                                    ( ty1 + 1 - ty0 ) ];
            g.setColor( 0xFFFFFF );
            int y = ty0 * tilesize - y0;
            for ( int ty=ty0; ty<=ty1; ty++ ) {
                int x = tx0 * tilesize - x0;
                for ( int tx=tx0; tx<=tx1; tx++ ) {
                    Image image = loadTile( tx, ty );
                    newcache[ cacheIndex++ ] =
                        new CacheEntry( tx, ty, zoom, image );
                    if ( image == null )
                        image = mapVendorImage;
                    g.drawImage( image, x, y,
                                 Graphics.LEFT | Graphics.TOP );
                    if ( image.getWidth() < tilesize ) {
                        g.fillRect( x + image.getWidth(), y,
                                    tilesize - image.getWidth(),
                                    image.getHeight() );
                    };
                    if ( image.getHeight() < tilesize ) {
                        g.fillRect( x, y + image.getHeight(),
                                    tilesize,
                                    tilesize - image.getHeight() );
                    };
                    x += tilesize;
                }
                y += tilesize;
            }

            if ( hasMarker ) {
                int
                    mx = ( markX - posx ) / zoom + getWidth()  / 2,
                    my = ( markY - posy ) / zoom + getHeight() / 2;
                g.setColor( 0xFF0000 );
                g.drawArc( mx - markerSize / 2, my - markerSize / 2,
                           markerSize, markerSize, 0, 360 );
                g.drawLine( mx, my - markerSize / 2, mx, my + markerSize / 2 );
                g.drawLine( mx - markerSize / 2, my, mx + markerSize / 2, my );
                g.setStrokeStyle( Graphics.DOTTED );
                g.drawLine( getWidth() / 2, getHeight() / 2, mx, my );
                g.setStrokeStyle( Graphics.SOLID );
            };
        
            cache = newcache;
        } else {
            g.setColor( 0xFFFFFF );
            g.fillRect( 0, 0, getWidth(), getHeight() );
            g.setColor( 0xFF0000 );
            g.drawString( "File '/wedesoft/mobinav/mapvendor.png' not found",
                          ( getWidth()  / 2 - posx ) / zoom + getWidth()  / 2,
                          ( getHeight() / 2 - posy ) / zoom + getHeight() / 2,
                          Graphics.HCENTER | Graphics.BASELINE );
        };
    };

    public void keyPressed(int code) {

        boolean changed = true;
        int step;
        if ( markerMode )
            step = markerSize / 2 * zoom;
        else
            step = ( getWidth() / 4 ) * zoom;

        switch ( code ) {
        case Canvas.KEY_NUM2:
            posy -= step;
            break;
        case Canvas.KEY_NUM8:
            posy += step;
            break;
        case Canvas.KEY_NUM4:
            posx -= step;
            break;
        case Canvas.KEY_NUM6:
            posx += step;
            break;
        case Canvas.KEY_NUM1:
        case Canvas.KEY_NUM7:
        case Canvas.KEY_STAR:
            if ( maxtiles >= 10 )
                zoomOut();
            else
                changed = false;
            break;
        case Canvas.KEY_NUM3:
        case Canvas.KEY_NUM9:
        case Canvas.KEY_POUND:
            if ( zoom >= 2 )
                zoomIn();
            else
                changed = false;
            break;

        default:
            switch ( getGameAction( code ) ) {
            case Canvas.UP:
                posy -= step;
                break;
            case Canvas.DOWN:
                posy += step;
                break;
            case Canvas.LEFT:
                posx -= step;
                break;
            case Canvas.RIGHT:
                posx += step;
                break;
            default:
                changed = false;
            }

        }

        if ( markerMode ) {
            markX = posx;
            markY = posy;
        }

        if ( changed )
            repaint();
    }

    Image loadTile( int x, int y ) {
        Image retval = null;
        if ( x >= 0 && y >= 0 && x < maxtiles && y < maxtiles ) {
            String fileName = "/wedesoft/mobinav/" +
                ( maxtiles + x ) + ( maxtiles + y ) + ".png";
            try {
                for ( int i=0; i<cache.length; i++ )
                    if ( cache[i].match( x, y, zoom ) ) {
                        retval = cache[i].getImage();
                        break;
                    };
                if ( retval == null )
                    retval = Image.createImage( fileName );
            } catch (IOException e ) {
                retval = null;
            }
        }
        return retval;
    }

    protected int sample( int x, int rate ) {
        int retval;
        if ( x >= 0 )
            retval = x / rate;
        else
            retval = -sample( rate - 1 - x, rate );
        return retval;
    };

    protected void zoomIn() {
        if ( zoom > 1 ) {
            zoom /= 2;
            maxtiles *= 10;
            updateEnabled();
        };
    }
   
    protected void zoomOut() {
        if ( maxtiles >= 10 ) {
            zoom *= 2;
            maxtiles /= 10;
            updateEnabled();
        }
    }

    protected void loadOptions() {
        // zoom must be 1!
        reset();
        try {
            RecordStore settings =
                RecordStore.openRecordStore("Settings", true);
            try {
                posx = Integer.valueOf( new String( settings.getRecord( 1 ) ) )
                    .intValue();
                posy = Integer.valueOf( new String( settings.getRecord( 2 ) ) )
                    .intValue();
                zoom = Integer.valueOf( new String( settings.getRecord( 3 ) ) )
                    .intValue();
                hasMarker = Integer.valueOf( new String( settings.getRecord( 4 ) ) )
                    .intValue() != 0;
                markX = Integer.valueOf( new String( settings.getRecord( 5 ) ) )
                    .intValue();
                markY = Integer.valueOf( new String( settings.getRecord( 6 ) ) )
                    .intValue();
                for ( int x = zoom; x > 1; x /= 2 )
                    maxtiles /= 10;
                updateEnabled();
            } catch ( RecordStoreException rse ) {
            }
            settings.closeRecordStore();
        } catch (Exception e) {
        }
    }
    protected void saveOptions() {
        try {
            RecordStore settings =
                RecordStore.openRecordStore( "Settings", true );
            String
                posxstr = String.valueOf( posx ),
                posystr = String.valueOf( posy ),
                zoomstr = String.valueOf( zoom ),
                hasMarkerStr = hasMarker ? "1" : "0",
                markXStr = String.valueOf( markX ),
                markYStr = String.valueOf( markY );
            try {
                settings.setRecord( 1, posxstr.getBytes(),
                                    0, posxstr.length() );
                settings.setRecord( 2, posystr.getBytes(),
                                    0, posystr.length() );
                settings.setRecord( 3, zoomstr.getBytes(),
                                    0, zoomstr.length() );
                settings.setRecord( 4, hasMarkerStr.getBytes(),
                                    0, hasMarkerStr.length() );
                settings.setRecord( 5, markXStr.getBytes(),
                                    0, markXStr.length() );
                settings.setRecord( 6, markYStr.getBytes(),
                                    0, markYStr.length() );
            } catch (RecordStoreException rse) {
                settings.addRecord( posxstr.getBytes(), 0, posxstr.length() );
                settings.addRecord( posystr.getBytes(), 0, posystr.length() );
                settings.addRecord( zoomstr.getBytes(), 0, zoomstr.length() );
                settings.addRecord( hasMarkerStr.getBytes(), 0, hasMarkerStr.length() );
                settings.addRecord( markXStr.getBytes(), 0, markXStr.length() );
                settings.addRecord( markYStr.getBytes(), 0, markYStr.length() );
            }
            settings.closeRecordStore();
        } catch (Exception e) {
        }
    }

    protected void setMarkerMode( boolean on ) {
        if ( on ) {
            removeCommand( cmdExit );
            addCommand( cmdOk );
            addCommand( cmdCancel );
            removeCommand( cmdSetMarker );
            removeCommand( cmdReset );
            removeCommand( cmdAbout );
        } else {
            addCommand( cmdExit );
            removeCommand( cmdOk );
            removeCommand( cmdCancel );
            if ( mapVendorImage != null )
                addCommand( cmdSetMarker );
            else
                removeCommand( cmdSetMarker );
            addCommand( cmdReset );
            addCommand( cmdAbout );
        };
        markerMode = on;
    }
   
    public void commandAction( Command c, Displayable s ) { 
        if ( c == cmdExit ) {
            saveOptions();
            midlet.notifyDestroyed();
        } else if ( c == cmdZoomIn ) {
            zoomIn();
            repaint();
        } else if ( c == cmdZoomOut ) {
            zoomOut();
            repaint();
        } else if ( c == cmdReset ) {
            reset();
            try {
                RecordStore.deleteRecordStore( "Settings" );
            } catch ( RecordStoreException rex ) {
            }
            repaint();
        } else if ( c == cmdAbout ) {
            About.showAbout( dpy );
        } else if ( c == cmdSetMarker ) {
            setMarkerMode( true );
            oldPosX = posx;
            oldPosY = posy;
            if ( hasMarker ) {
                posx = markX;
                posy = markY;
            } else {
                markX = posx;
                markY = posy;
                hasMarker = true;
            };
            repaint();
        } else if ( c == cmdOk ) {
            setMarkerMode( false );
            posx = oldPosX;
            posy = oldPosY;
            hasMarker = true;
            repaint();
        } else  if ( c == cmdCancel ) {
            setMarkerMode( false );
            posx = oldPosX;
            posy = oldPosY;
            hasMarker = false;
            repaint();
        }
    } 
}
